<template>
  <div class="flex flex-col pb-20">
    <div class="container px-4 py-20 mx-auto">
      <h1
        class="text-2xl font-extrabold leading-tight text-center text-gray-900 sm:text-3xl md:text-4xl"
      >
        PRODUK KAMI
      </h1>
    </div>
    <div class="container mx-auto">
      <div
        class="grid gap-8 text-center md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
      >
        <div
          class="flex flex-col items-center flex-1 p-4 space-y-3 rounded shadow bg-gray-50"
        >
          <a
            href="javascript:void(0)"
            class="flex items-center justify-center w-full px-3 py-8"
          >
            <img src="@/assets/img/product/kpi.png" alt="" class="h-32" />
          </a>
          <h2 class="text-2xl font-bold text-black">
            Penilaian KPI
          </h2>
          <div>
            <p class="text-xl font-black">Rp. 25.000, -</p>
            <p class="text-xs text-left text-gray-400">per user, per month</p>
          </div>
          <div class="space-y-1">
            <p>Penilaian Kinerja Karyawan</p>
            <p>Database Karyawan</p>
          </div>
          <div class="flex p-4 space-x-3 text-sm">
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-red-700 rounded-xl"
            >
              Info Produk
            </button>
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-green-700 rounded-xl"
            >
              Coba Sekarang
            </button>
          </div>
        </div>
        <div
          class="flex flex-col items-center flex-1 p-4 space-y-3 rounded shadow bg-gray-50"
        >
          <a
            href="javascript:void(0)"
            class="flex items-center justify-center w-full px-3 py-8"
          >
            <img
              src="@/assets/img/product/sales_visitation.png"
              alt=""
              class="h-32"
            />
          </a>
          <h2 class="text-2xl font-bold text-black">
            Sales Visitation
          </h2>
          <div>
            <p class="text-xl font-black">Rp. 20.000, -</p>
            <p class="text-xs text-left text-gray-400">per user, per month</p>
          </div>
          <div class="space-y-1">
            <p>Absensi Sales</p>
            <p>Laporan Kunjungan Sales</p>
          </div>
          <div class="flex p-4 space-x-3 text-sm">
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-red-700 rounded-xl"
            >
              Info Produk
            </button>
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-green-700 rounded-xl"
            >
              Coba Sekarang
            </button>
          </div>
        </div>
        <div
          class="flex flex-col items-center flex-1 p-4 space-y-3 rounded shadow bg-gray-50"
        >
          <a
            href="javascript:void(0)"
            class="flex items-center justify-center w-full px-3 py-8"
          >
            <img src="@/assets/img/product/absensi.png" alt="" class="h-32" />
          </a>
          <h2 class="text-2xl font-bold text-black">
            Absensi
          </h2>
          <div>
            <p class="text-xl font-black">Rp. 20.000, -</p>
            <p class="text-xs text-left text-gray-400">per user, per month</p>
          </div>
          <div class="space-y-1">
            <p>Absensi Karyawan</p>
            <p>Menggunakan Geolokasi</p>
          </div>
          <div class="flex p-4 space-x-3 text-sm">
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-red-700 rounded-xl"
            >
              Info Produk
            </button>
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-green-700 rounded-xl"
            >
              Coba Sekarang
            </button>
          </div>
        </div>
        <div
          class="flex flex-col items-center flex-1 p-4 space-y-3 rounded shadow bg-gray-50"
        >
          <a
            href="javascript:void(0)"
            class="flex items-center justify-center w-full px-3 py-8"
          >
            <img src="@/assets/img/product/checkin.png" alt="" class="h-32" />
          </a>
          <h2 class="text-2xl font-bold text-black">
            Checkin
          </h2>
          <div>
            <p class="text-xl font-black">FREE, -</p>
            <p class="text-xs text-left text-gray-400">&nbsp;</p>
          </div>
          <div class="space-y-1">
            <p>Tag Lokasi</p>
            <p>Menggunakan Photo & Geolokasi</p>
          </div>
          <div class="flex p-4 space-x-3 text-sm">
            <button
              class="px-8 py-3 font-bold text-white uppercase bg-red-700 rounded-xl"
            >
              Info Produk
            </button>
            <a
              href="https://checkin.pointhub.net/signup"
              class="px-8 py-3 font-bold text-white uppercase bg-green-700 rounded-xl"
            >
              Coba Sekarang
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {}
};
</script>
